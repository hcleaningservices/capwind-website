CAPWIND SRL — WEBSITE PACKAGE

1. Extract the ZIP file.
2. Open index.html to preview the website in a browser.
3. To publish, upload index.html and the assets folder together to your website hosting.
4. The service request form uses FormSubmit (formsubmit.co) and sends to capwindsrl@gmail.com. On first submission, the mailbox owner MUST click the activation/confirmation link emailed by FormSubmit before forms can be delivered. Test the form after activation.
5. The form sends requests only. CAPWIND chooses and confirms all appointments manually. No calendar, database or private dashboard is included.
6. Confirm all services, legal registration details, privacy disclosures, and any photo permissions before publishing.
7. The website supports FR, EN, DE, NL.
